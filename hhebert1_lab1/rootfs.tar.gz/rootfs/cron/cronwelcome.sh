#!/bin/sh

echo "Welcome to EC535! Welcome to the Spring 2017 Semester!" > /dev/ttyS0
echo "Current date and time: $(date)" > /dev/ttyS0
sleep 10;
echo "Welcome to EC535! Welcome to the Spring 2017 Semester!" > /dev/ttyS0
echo "Current date and time: $(date)" > /dev/ttyS0
sleep 10;
echo "Welcome to EC535! Welcome to the Spring 2017 Semester!" > /dev/ttyS0
echo "Current date and time: $(date)" > /dev/ttyS0
sleep 10;
echo "Welcome to EC535! Welcome to the Spring 2017 Semester!" > /dev/ttyS0
echo "Current date and time: $(date)" > /dev/ttyS0
sleep 10;
echo "Welcome to EC535! Welcome to the Spring 2017 Semester!" > /dev/ttyS0
echo "Current date and time: $(date)" > /dev/ttyS0
sleep 10;
echo "Welcome to EC535! Welcome to the Spring 2017 Semester!" > /dev/ttyS0
echo "Current date and time: $(date)" > /dev/ttyS0
sleep 10;


